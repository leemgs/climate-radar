# Climate RADAR Mobile (Prototype)

This is a minimal web‑previewable scaffold for the citizen app UI. For a production mobile build, start from Expo or React Native CLI and port these flows.

- Shows how to call `/api/recommendation` and display the AI action card.
- Replace with real screens (Home, Action Cards, Check‑in, Request Help).
