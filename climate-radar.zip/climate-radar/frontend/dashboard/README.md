# Climate RADAR Dashboard (Prototype)

Static, zero‑build React sample that fetches the API:
- `/api/dashboard/summary`
- `/api/dashboard/heatmap_data`

Serve locally (simple dev):
```bash
python -m http.server 5173
# open http://127.0.0.1:5173
```
